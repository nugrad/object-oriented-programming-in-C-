#include<iostream>
using namespace std;
int main()
{
    float mph;
    float v;
    cout<<"enter speed\n";
    cin>>v;
    mph=v*0.624;
    cout<<"peed in mph\n";
    cout<<"\n";
    cout<<mph;
}
